// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("autosar check"); }
int main(){
  announce();
  return lionss_run_workload("autosar-check");
}
