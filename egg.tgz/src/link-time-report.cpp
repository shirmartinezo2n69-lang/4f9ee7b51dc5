// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("link time report\n", stdout);
  return lionss_run_workload("link-time-report");
}
