// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("dragonfly build\n", stdout);
  return lionss_run_workload("dragonfly-build");
}
