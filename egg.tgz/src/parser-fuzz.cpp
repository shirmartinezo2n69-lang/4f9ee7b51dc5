// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("parser fuzz\n", stdout);
  return lionss_run_workload("parser-fuzz");
}
