// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("alpine build"); }
int main(){
  announce();
  return lionss_run_workload("alpine-build");
}
